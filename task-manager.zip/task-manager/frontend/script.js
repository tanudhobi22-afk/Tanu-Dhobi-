const API_BASE = 'http://localhost:5000/api/tasks';

let tasks = [];
let currentFilter = 'all';

const taskListEl = document.getElementById('taskList');
const taskForm = document.getElementById('taskForm');
const taskInput = document.getElementById('taskInput');
const loadingMsg = document.getElementById('loadingMsg');
const errorMsg = document.getElementById('errorMsg');
const filterBtns = document.querySelectorAll('.filter-btn');

function setLoading(show) {
  loadingMsg.classList.toggle('hidden', !show);
}

function showError(message) {
  errorMsg.textContent = message;
  errorMsg.classList.remove('hidden');
  setTimeout(() => errorMsg.classList.add('hidden'), 3000);
}

async function fetchTasks() {
  setLoading(true);
  try {
    const res = await fetch(API_BASE);
    if (!res.ok) throw new Error('Failed to fetch tasks');
    tasks = await res.json();
    renderTasks();
  } catch (err) {
    showError('Could not load tasks');
  } finally {
    setLoading(false);
  }
}

async function addTask(title) {
  try {
    const res = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title })
    });
    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error || 'Failed to add task');
    }
    await fetchTasks();
  } catch (err) {
    showError(err.message);
  }
}

async function updateTask(id, updates) {
  try {
    const res = await fetch(`${API_BASE}/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (!res.ok) throw new Error('Update failed');
    await fetchTasks();
  } catch (err) {
    showError(err.message);
  }
}

async function deleteTask(id) {
  if (!confirm('Delete this task?')) return;
  try {
    const res = await fetch(`${API_BASE}/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Delete failed');
    await fetchTasks();
  } catch (err) {
    showError(err.message);
  }
}

function editTaskPrompt(id, currentTitle) {
  const newTitle = prompt('Edit task title:', currentTitle);
  if (newTitle && newTitle.trim() !== currentTitle) {
    updateTask(id, { title: newTitle.trim() });
  }
}

function renderTasks() {
  let filtered = tasks;
  if (currentFilter === 'active') filtered = tasks.filter(t => !t.completed);
  if (currentFilter === 'completed') filtered = tasks.filter(t => t.completed);

  if (filtered.length === 0) {
    taskListEl.innerHTML = '<li class="task-item">✨ No tasks here</li>';
    return;
  }

  taskListEl.innerHTML = filtered.map(task => `
    <li class="task-item ${task.completed ? 'completed' : ''}" data-id="${task.id}">
      <input type="checkbox" ${task.completed ? 'checked' : ''} class="task-checkbox">
      <span class="task-title">${escapeHtml(task.title)}</span>
      <button class="edit-btn">✏️ Edit</button>
      <button class="delete-btn">🗑️ Delete</button>
    </li>
  `).join('');

  document.querySelectorAll('.task-item').forEach(item => {
    const id = item.dataset.id;
    const checkbox = item.querySelector('.task-checkbox');
    const editBtn = item.querySelector('.edit-btn');
    const deleteBtn = item.querySelector('.delete-btn');
    
    checkbox.addEventListener('change', () => updateTask(id, { completed: checkbox.checked }));
    editBtn.addEventListener('click', () => {
      const originalTask = tasks.find(t => t.id === id);
      if (originalTask) editTaskPrompt(id, originalTask.title);
    });
    deleteBtn.addEventListener('click', () => deleteTask(id));
  });
}

function escapeHtml(str) {
  return str.replace(/[&<>]/g, function(m) {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
}

filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    renderTasks();
  });
});

taskForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const title = taskInput.value.trim();
  if (title) {
    addTask(title);
    taskInput.value = '';
  }
});

fetchTasks();