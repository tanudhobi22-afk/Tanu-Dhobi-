const fs = require('fs').promises;
const path = require('path');

const dataDir = path.join(__dirname, '../data');
const dataFile = path.join(dataDir, 'tasks.json');

async function ensureDataFile() {
  try {
    await fs.access(dataDir);
  } catch {
    await fs.mkdir(dataDir, { recursive: true });
  }
  try {
    await fs.access(dataFile);
  } catch {
    await fs.writeFile(dataFile, JSON.stringify([]));
  }
}

async function readTasks() {
  await ensureDataFile();
  const data = await fs.readFile(dataFile, 'utf8');
  return JSON.parse(data);
}

async function writeTasks(tasks) {
  await ensureDataFile();
  await fs.writeFile(dataFile, JSON.stringify(tasks, null, 2));
}

module.exports = { readTasks, writeTasks };