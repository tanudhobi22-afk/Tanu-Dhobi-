function validateTask(title) {
  if (!title || typeof title !== 'string') return 'Title is required';
  if (title.trim().length === 0) return 'Title cannot be empty';
  if (title.trim().length > 200) return 'Title too long (max 200 chars)';
  return null;
}

function validateUpdate(updates) {
  if (updates.title !== undefined) {
    const err = validateTask(updates.title);
    if (err) return err;
  }
  if (updates.completed !== undefined && typeof updates.completed !== 'boolean') {
    return 'completed must be a boolean value';
  }
  return null;
}

module.exports = { validateTask, validateUpdate };