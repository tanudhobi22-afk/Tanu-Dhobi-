const { readTasks, writeTasks } = require('../utils/storage');
const { validateTask, validateUpdate } = require('../utils/validation');

exports.getAllTasks = async (req, res) => {
  const tasks = await readTasks();
  res.json(tasks);
};

exports.createTask = async (req, res) => {
  const { title } = req.body;
  const error = validateTask(title);
  if (error) return res.status(400).json({ error });

  const tasks = await readTasks();
  const newTask = {
    id: crypto.randomUUID(),
    title: title.trim(),
    completed: false,
    createdAt: new Date().toISOString()
  };
  tasks.push(newTask);
  await writeTasks(tasks);
  res.status(201).json(newTask);
};

exports.updateTask = async (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  const error = validateUpdate(updates);
  if (error) return res.status(400).json({ error });

  const tasks = await readTasks();
  const index = tasks.findIndex(t => t.id === id);
  if (index === -1) return res.status(404).json({ error: 'Task not found' });

  tasks[index] = { ...tasks[index], ...updates };
  await writeTasks(tasks);
  res.json(tasks[index]);
};

exports.deleteTask = async (req, res) => {
  const { id } = req.params;
  let tasks = await readTasks();
  const newTasks = tasks.filter(t => t.id !== id);
  if (newTasks.length === tasks.length) return res.status(404).json({ error: 'Task not found' });
  await writeTasks(newTasks);
  res.status(204).send();
};